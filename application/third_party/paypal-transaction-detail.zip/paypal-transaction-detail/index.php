<?php
// # GetPaymentSample
// This sample code demonstrate how you can
// retrieve a list of all Payment resources
// you've created using the Payments API.
// ### Retrieve payment
// Retrieve the payment object by calling the
// static `get` method
// on the Payment class by passing a valid
// Payment ID
// (See bootstrap.php for more on `ApiContext`)
require __DIR__ . '/bootstrap.php';

use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\CreditCard;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\FundingInstrument;
use PayPal\Api\Transaction;

if (isset($_POST['submit'])) {
    $paymentId = $_POST['paymentId'];
    try {
        $payment = Payment::get($paymentId, $apiContext);
        $obj = json_decode($payment); // $obj contains the All Transaction Information.Some of them,I have displayed Below. 
    } catch (Exception $ex) {
        $payment = 'Not Valid';
    }  
}
?>
<html>
    <head>
        <title>PayPal Transaction Details using Transaction  Id</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/popup-style.css" />
        <script src="js/jquery-latest.js" type="text/javascript"></script>
		<meta name="robots" content="noindex, nofollow">
		<script type="text/javascript">
           var _gaq = _gaq || [];
           _gaq.push(['_setAccount', 'UA-43981329-1']);
           _gaq.push(['_trackPageview']);
           (function () {
               var ga = document.createElement('script');
               ga.type = 'text/javascript';
               ga.async = true;
               ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
               var s = document.getElementsByTagName('script')[0];
               s.parentNode.insertBefore(ga, s);
           })();
       </script>
    </head>
    <body>
        <div id = "main">
            <h1>PayPal Transaction Details using Transaction Id</h1>
            <div id = "login">
                <h2>Transaction Detail</h2>
                <hr/>
                <div id="search">
                    <table id="results" >
                        <thead>
                            <tr class="head">
                                <th>Enter TransactionID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <form action="index.php" method="POST">
                                        <input type="text" name="paymentId">
                                        <input type="submit" id="submit" value="Search Detail By TransactionID" name="submit">
                                    </form> 
                                </td>
                            </tr>
                        </tbody>   
                    </table>
                </div>
                <div id="demo_id">
                    <table id="results" >
                        <thead>
                            <tr class="head">
                                <th>Demo TransactionID</th>
                            </tr>
                        </thead>
                        <tbody id="left90">
                            <tr>
                                <td>PAY-2WN6537138591315GKUTEVSI</td>
                            </tr>
                            <tr>
                                <td>PAY-95C53794T9204671MKUTEWFQ</td>
                            </tr>
                            <tr>
                                <td>PAY-1GX074103A011743DKUTEWYA</td>
                            </tr>
                            <tr>
                                <td>PAY-1C959132H6742844RKUTVN5A</td>
                            </tr>
                        </tbody>   
                    </table>
                </div>
                <?php
                if (isset($_POST['submit'])) {
                    if ($payment !== 'Not Valid') {
                        ?>
                        <table id="results" class="messages">
                            <thead>
                                <tr class="head">
                                    <th colspan="2">Payer Detail</th>

                                </tr>
                            </thead>
                            <tbody id="left90">
                                <tr>
                                    <td>TransactionID</td>
                                    <td><?php echo $obj->id; ?></td>
                                </tr>
                                <tr>
                                    <td>Payment Method</td>
                                    <td><?php echo $obj->payer->payment_method; ?></td>

                                </tr>
                                <tr>
                                    <td>Full Name</td>
                                    <td><?php
                                        echo $obj->payer->payer_info->first_name;
                                        echo ' ';
                                        echo $obj->payer->payer_info->last_name;
                                        ?></td>
                                </tr>
                                <tr>
                                    <td>Email</td>
                                    <td><?php echo $obj->payer->payer_info->email; ?></td>
                                </tr>
                                <tr>
                                    <td>Payer ID</td>
                                    <td><?php echo $obj->payer->payer_info->payer_id; ?></td>
                                </tr>
                                <tr>
                                    <td>Address</td>
                                    <td><ul style="text-align: left;">
                                            <li><?php echo "Line1 --> " . $obj->payer->payer_info->shipping_address->line1 ?></li>
                                            <li><?php echo "City --> " . $obj->payer->payer_info->shipping_address->city ?></li>
                                            <li><?php echo "State --> " . $obj->payer->payer_info->shipping_address->state ?></li>
                                            <li><?php echo "Postal Code --> " . $obj->payer->payer_info->shipping_address->postal_code ?></li>
                                            <li><?php echo "Country Code --> " . $obj->payer->payer_info->shipping_address->country_code ?></li>
                                            <li><?php echo "Recipient Name --> " . $obj->payer->payer_info->shipping_address->recipient_name ?></li>
                                        </ul></td>
                                </tr>
                                <tr>
                                    <td>Status</td>
                                    <td><?php echo $obj->payer->status; ?>
                                    </td>
                                </tr>
                            </tbody>
                            <thead>
                                <tr class = "head">
                                    <th colspan = "2">Transactions Detail</th>
                                </tr>
                            </thead>
                            <tbody id="left90">
                                <tr><td>Invoice_Number</td>
                                    <td><?php echo $obj->transactions[0]->invoice_number; ?></td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>Total Amount</td>
                                    <td>
                                        <ul style="text-align: left;">
                                            <li><?php echo "Total Amount --> " . $obj->transactions[0]->amount->total ?></li>
                                            <li><?php echo "Currency --> " . $obj->transactions[0]->amount->currency ?></li>
                                        </ul>
                                    </td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>Description</td>
                                    <td><?php echo $obj->transactions[0]->description; ?></td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>State</td>
                                    <td><?php echo $obj->transactions[0]->related_resources[0]->sale->state; ?></td>
                                </tr>
                            </tbody>
                            <thead id="left90">
                                <tr class = "head">
                                    <th colspan = "2">Item Detail</th>
                                </tr>
                            </thead>
                            <tbody id="left90">
                                <tr><td>Item Name</td>
                                    <td><?php echo $obj->transactions[0]->item_list->items[0]->name; ?></td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>Price</td>
                                    <td><?php echo $obj->transactions[0]->item_list->items[0]->price; ?></td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>Currency</td>
                                    <td><?php echo $obj->transactions[0]->item_list->items[0]->currency; ?></td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>Quantity</td>
                                    <td><?php echo $obj->transactions[0]->item_list->items[0]->quantity; ?></td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>Create Time</td>
                                    <td><?php echo $obj->create_time; ?></td>
                                </tr>
                            </tbody>
                            <tbody id="left90">
                                <tr><td>Update Time</td>
                                    <td><?php echo $obj->update_time; ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <?php } else if ($payment === 'Not Valid') {
                        ?>
                        <table id="results" class="messages">
                            <thead>
                                <tr class="head">
                                    <th colspan="2"><span>Enter Valid Transaction ID.</span></th>

                                </tr>
                            </thead>
                        </table>
                    <?php }
                }
                ?>
            </div>
            <img id="paypal_logo" style="margin-left: 722px;" src="images/secure-paypal-logo.jpg">
        </div>
        <div id="pop2" class="simplePopup">
            <div id="loader"><img src="images/ajax-loader.gif"/><img id="processing_animation" src="images/processing_animation.gif"/></div>
        </div>
        <script src="js/jquery.simplePopup.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('input#submit').click(function() {
                    $('#pop2').simplePopup();
                });
            });
        </script>
    </body>
</html>